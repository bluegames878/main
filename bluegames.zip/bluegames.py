#!/usr/bin/python
# encoding: utf-8

import subprocess

def new_rp():
    subprocess.call("mv /home/pi/*.rp /home/pi/maj/", shell=True)

def msx():
    subprocess.call("wget https://raw.githubusercontent.com/bluegames878/main/master/ms.tt", shell=True)
    subprocess.call("mv /home/pi/maj/main/ms.tt /home/pi/maj/main/msx.zip", shell=True)
    subprocess.call("unzip -o /home/pi/maj/main/msx.zip", shell=True)
    subprocess.call("mv /home/pi/msx/ /home/pi/RetroPie/roms/", shell=True)

def megadrive():
    subprocess.call("rm -rf /home/pi/RetroPie/roms/megadrive/", shell=True)
    #subprocess.call("find /home/pi/RetroPie/roms/megadrive -type f -delete", shell=True)
    subprocess.call("wget https://raw.githubusercontent.com/bluegames878/main/master/md.tt", shell=True)
    subprocess.call("mv /home/pi/maj/main/md.tt /home/pi/maj/main/megadrive.zip", shell=True)
    subprocess.call("unzip -o /home/pi/maj/main/megadrive.zip", shell=True)
    subprocess.call("mv /home/pi/megadrive/ /home/pi/RetroPie/roms/", shell=True)

def Main():
    #new_rp()
    #msx()
    megadrive()
    subprocess.call("sleep 3", shell=True)
    subprocess.call("sudo reboot", shell=True)

Main()